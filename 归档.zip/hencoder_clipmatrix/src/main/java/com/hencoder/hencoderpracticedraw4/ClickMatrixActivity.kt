package com.hencoder.hencoderpracticedraw4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ClickMatrixActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
