package com.hencoder.hencoderpracticedraw2

import com.apache.fastandroid.hencoder.paint.databinding.ActivityMainBinding
import com.tesla.framework.ui.activity.BaseVmActivity

/**
 * Created by Jerry on 2022/4/17.
 */
class PaintEnterActivity:BaseVmActivity<ActivityMainBinding>(ActivityMainBinding::inflate) {
}