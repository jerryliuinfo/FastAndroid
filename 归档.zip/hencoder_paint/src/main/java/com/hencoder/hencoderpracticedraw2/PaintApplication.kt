package com.hencoder.hencoderpracticedraw2

import android.app.Application

/**
 * Created by Jerry on 2022/4/17.
 */
class PaintApplication: Application() {
}