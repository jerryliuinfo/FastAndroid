package com.apache.fastandroid.hencoder.basic

import com.apache.fastandroid.hencoder.basic.databinding.ActivityMainBinding
import com.tesla.framework.ui.activity.BaseVmActivity

/**
 * Created by Jerry on 2022/4/17.
 */
class BasicEnterActivity:BaseVmActivity<ActivityMainBinding>(ActivityMainBinding::inflate) {
}