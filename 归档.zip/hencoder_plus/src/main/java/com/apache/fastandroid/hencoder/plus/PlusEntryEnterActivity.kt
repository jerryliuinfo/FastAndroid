package com.apache.fastandroid.hencoder.plus

import com.apache.fastandroid.hencoder.hencoder_plus.databinding.ActivityMainBinding
import com.tesla.framework.ui.activity.BaseVmActivity

/**
 * Created by Jerry on 2022/4/17.
 */
class PlusEntryEnterActivity:BaseVmActivity<ActivityMainBinding>(ActivityMainBinding::inflate){
}