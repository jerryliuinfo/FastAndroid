package com.apache.fastandroid.hencoder.plus

import android.app.Application

/**
 * Created by Jerry on 2022/4/17.
 */
class PlusApplication: Application() {
}