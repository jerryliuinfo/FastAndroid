object AppConfig {
    const val compileSdk = 31
    const val minSdk = 24
    const val targetSdk = 31
}